<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quản lý Product (AJAX)</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>var contextPath = "${pageContext.request.contextPath}"</script>
</head>
<body class="bg-light">
<div class="container my-4">
	<div class="d-flex justify-content-between align-items-center mb-3">
		<h3>Quản lý Product (CRUD bằng REST API + AJAX)</h3>
		<div>
			<a href="${pageContext.request.contextPath}/category" class="btn btn-outline-secondary">Sang trang Category</a>
			<a href="${pageContext.request.contextPath}/swagger-ui.html" target="_blank" class="btn btn-outline-dark">Swagger API</a>
		</div>
	</div>

	<div class="row mb-3">
		<div class="col-md-4">
			<div class="input-group">
				<input type="text" class="form-control" id="searchKeyword" placeholder="Tìm theo tên sản phẩm...">
				<button class="btn btn-outline-primary" onclick="searchProducts()">Tìm</button>
				<button class="btn btn-outline-secondary" onclick="$('#searchKeyword').val('');loadProducts();">Xóa lọc</button>
			</div>
		</div>
	</div>

	<p><button class="btn btn-success" onclick="showCreateNewProductModal()">
		<i class="fas fa-plus me-2"></i>Thêm Product (Ajax)
	</button></p>

	<table class="table table-striped table-bordered bg-white">
		<thead class="table-dark">
			<tr>
				<th>Id</th><th>Ảnh</th><th>Tên SP</th><th>Danh mục</th><th>SL</th><th>Giá</th><th>Giảm giá</th><th>Trạng thái</th><th>Actions</th>
			</tr>
		</thead>
		<tbody id="productTableBody"></tbody>
	</table>
</div>

<!-- ============ Modal Thêm Product ============ -->
<div class="modal" tabindex="-1" role="dialog" id="createProductModal">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<form id="addProduct" method="post" onsubmit="return false;" enctype="multipart/form-data">
				<div class="modal-header">
					<h5 class="modal-title">Thêm Product</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
				</div>
				<div class="modal-body">
					<div class="mb-2">
						<label class="form-label">Tên sản phẩm</label>
						<input type="text" class="form-control" name="productName" required>
					</div>
					<div class="mb-2">
						<label class="form-label">Danh mục</label>
						<select class="form-select" name="categoryId" id="new_categoryId" required></select>
					</div>
					<div class="row">
						<div class="col-md-6 mb-2">
							<label class="form-label">Số lượng</label>
							<input type="number" class="form-control" name="quantity" value="0" required>
						</div>
						<div class="col-md-6 mb-2">
							<label class="form-label">Đơn giá</label>
							<input type="number" step="1000" class="form-control" name="unitPrice" value="0" required>
						</div>
					</div>
					<div class="mb-2">
						<label class="form-label">Giảm giá</label>
						<input type="number" step="1000" class="form-control" name="discount" value="0">
					</div>
					<div class="mb-2">
						<label class="form-label">Mô tả</label>
						<textarea class="form-control" name="description" rows="2"></textarea>
					</div>
					<div class="mb-2">
						<label class="form-label">Ảnh</label>
						<input type="file" class="form-control" name="imageFile">
					</div>
					<div class="mb-2">
						<label class="form-label">Trạng thái</label>
						<select class="form-select" name="status">
							<option value="1">Đang bán</option>
							<option value="0">Ngừng bán</option>
						</select>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
					<button type="submit" class="btn btn-primary">Thêm</button>
				</div>
			</form>
		</div>
	</div>
</div>

<!-- ============ Modal Sửa Product ============ -->
<div class="modal" tabindex="-1" role="dialog" id="updateProductModal">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<form id="updateProduct" method="post" onsubmit="return false;" enctype="multipart/form-data">
				<div class="modal-header">
					<h5 class="modal-title">Cập nhật Product</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
				</div>
				<div class="modal-body">
					<input type="hidden" name="productId" id="up_productId">
					<div class="mb-2">
						<label class="form-label">Tên sản phẩm</label>
						<input type="text" class="form-control" name="productName" id="up_productName" required>
					</div>
					<div class="mb-2">
						<label class="form-label">Danh mục</label>
						<select class="form-select" name="categoryId" id="up_categoryId" required></select>
					</div>
					<div class="row">
						<div class="col-md-6 mb-2">
							<label class="form-label">Số lượng</label>
							<input type="number" class="form-control" name="quantity" id="up_quantity" required>
						</div>
						<div class="col-md-6 mb-2">
							<label class="form-label">Đơn giá</label>
							<input type="number" step="1000" class="form-control" name="unitPrice" id="up_unitPrice" required>
						</div>
					</div>
					<div class="mb-2">
						<label class="form-label">Giảm giá</label>
						<input type="number" step="1000" class="form-control" name="discount" id="up_discount">
					</div>
					<div class="mb-2">
						<label class="form-label">Mô tả</label>
						<textarea class="form-control" name="description" id="up_description" rows="2"></textarea>
					</div>
					<div class="mb-2">
						<label class="form-label">Ảnh mới (để trống nếu không đổi)</label>
						<input type="file" class="form-control" name="imageFile">
					</div>
					<div class="mb-2">
						<label class="form-label">Trạng thái</label>
						<select class="form-select" name="status" id="up_status">
							<option value="1">Đang bán</option>
							<option value="0">Ngừng bán</option>
						</select>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
					<button type="submit" class="btn btn-primary">Cập nhật</button>
				</div>
			</form>
		</div>
	</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">
	var categoriesCache = [];

	/* ============ Load danh mục cho 2 dropdown ============ */
	function loadCategoriesDropdown() {
		$.getJSON(contextPath + '/api/category', function (resp) {
			categoriesCache = resp.body;
			var opts = categoriesCache.map(function (c) {
				return '<option value="' + c.categoryId + '">' + c.categoryName + '</option>';
			}).join('');
			$('#new_categoryId').html(opts);
			$('#up_categoryId').html(opts);
		});
	}

	function categoryName(categoryId) {
		var found = categoriesCache.find(function (c) { return c.categoryId === categoryId; });
		return found ? found.categoryName : '';
	}

	/* ============ Load danh sách Product bằng AJAX ============ */
	function loadProducts() {
		$.getJSON(contextPath + '/api/product', function (resp) {
			renderTable(resp.body);
		});
	}

	function searchProducts() {
		var kw = $('#searchKeyword').val();
		$.getJSON(contextPath + '/api/product/search?keyword=' + encodeURIComponent(kw) + '&page=0&size=50', function (resp) {
			renderTable(resp.body.content); // Page<Product> -> content
		});
	}

	function renderTable(list) {
		var tr = [];
		for (var i = 0; i < list.length; i++) {
			var p = list[i];
			var imgUrl = p.images ? (contextPath + '/images/' + p.images) : '';
			tr.push('<tr>');
			tr.push('<td>' + p.productId + '</td>');
			tr.push('<td>' + (imgUrl ? '<img src="' + imgUrl + '" style="width:60px" class="img-fluid" alt="">' : '') + '</td>');
			tr.push('<td>' + p.productName + '</td>');
			tr.push('<td>' + (p.category ? p.category.categoryName : '') + '</td>');
			tr.push('<td>' + p.quantity + '</td>');
			tr.push('<td>' + Number(p.unitPrice).toLocaleString('vi-VN') + '</td>');
			tr.push('<td>' + Number(p.discount).toLocaleString('vi-VN') + '</td>');
			tr.push('<td>' + (p.status == 1 ? 'Đang bán' : 'Ngừng bán') + '</td>');
			tr.push('<td>' +
				'<a href="#" class="btn btn-sm btn-outline-warning me-1" onclick=\'showEditProductModal(' + JSON.stringify(p) + ')\'>' +
				'<i class="fas fa-edit"></i></a>' +
				'<a href="#" class="btn btn-sm btn-outline-danger" data-id="' + p.productId + '" id="btnDeleteProduct">' +
				'<i class="fas fa-trash"></i></a>' +
				'</td>');
			tr.push('</tr>');
		}
		$('#productTableBody').html(tr.join(''));
	}

	$(document).ready(function () {
		loadCategoriesDropdown();
		loadProducts();
	});

	/* ============ Thêm Product ============ */
	function showCreateNewProductModal() {
		$('#addProduct')[0].reset();
		var modal = new bootstrap.Modal(document.getElementById('createProductModal'));
		modal.show();
	}
	$("form#addProduct").submit(function (e) {
		e.preventDefault();
		var formData = new FormData(this);
		$.ajax({
			url: contextPath + '/api/product/addProduct',
			type: 'POST',
			dataType: "json",
			data: formData,
			success: function () {
				bootstrap.Modal.getInstance(document.getElementById('createProductModal')).hide();
				loadProducts();
			},
			error: function (xhr) {
				alert('Lỗi: ' + (xhr.responseJSON ? xhr.responseJSON.message : xhr.responseText));
			},
			cache: false,
			contentType: false,
			processData: false
		});
	});

	/* ============ Sửa Product ============ */
	function showEditProductModal(p) {
		$('#up_productId').val(p.productId);
		$('#up_productName').val(p.productName);
		$('#up_categoryId').val(p.category ? p.category.categoryId : '');
		$('#up_quantity').val(p.quantity);
		$('#up_unitPrice').val(p.unitPrice);
		$('#up_discount').val(p.discount);
		$('#up_description').val(p.description);
		$('#up_status').val(p.status);
		var modal = new bootstrap.Modal(document.getElementById('updateProductModal'));
		modal.show();
	}
	$("form#updateProduct").submit(function (e) {
		e.preventDefault();
		var formData = new FormData(this);
		$.ajax({
			url: contextPath + '/api/product/updateProduct',
			type: 'PUT',
			dataType: "json",
			data: formData,
			success: function () {
				bootstrap.Modal.getInstance(document.getElementById('updateProductModal')).hide();
				loadProducts();
			},
			error: function (xhr) {
				alert('Lỗi: ' + (xhr.responseJSON ? xhr.responseJSON.message : xhr.responseText));
			},
			cache: false,
			contentType: false,
			processData: false
		});
	});

	/* ============ Xóa Product ============ */
	$(document).on('click', '#btnDeleteProduct', function () {
		var id = $(this).data('id');
		if (confirm('Bạn có chắc muốn xóa Product này?')) {
			$.ajax({
				type: "DELETE",
				url: contextPath + '/api/product/deleteProduct?productId=' + id,
				dataType: "json",
				success: function () {
					loadProducts();
				},
				error: function (xhr) {
					alert('Lỗi: ' + (xhr.responseJSON ? xhr.responseJSON.message : xhr.responseText));
				}
			});
		}
	});
</script>
</body>
</html>
