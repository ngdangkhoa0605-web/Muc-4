<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quản lý Category (AJAX)</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>var contextPath = "${pageContext.request.contextPath}"</script>
</head>
<body class="bg-light">
<div class="container my-4">
	<div class="d-flex justify-content-between align-items-center mb-3">
		<h3>Quản lý Category (CRUD bằng REST API + AJAX)</h3>
		<div>
			<a href="${pageContext.request.contextPath}/product" class="btn btn-outline-secondary">Sang trang Product</a>
			<a href="${pageContext.request.contextPath}/swagger-ui.html" target="_blank" class="btn btn-outline-dark">Swagger API</a>
		</div>
	</div>

	<p><button class="btn btn-success" onclick="showCreateNewCategoryModal()">
		<i class="fas fa-plus me-2"></i>Thêm Category (Ajax)
	</button></p>

	<table class="table table-striped table-bordered bg-white">
		<thead class="table-dark">
			<tr>
				<th>Id</th>
				<th>Icon</th>
				<th>Name</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody id="categoryTableBody"></tbody>
	</table>
</div>

<!-- ============ Modal Thêm Category ============ -->
<div class="modal" tabindex="-1" role="dialog" id="createCategoryModal">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<form id="addCategory" method="post" onsubmit="return false;" enctype="multipart/form-data">
				<div class="modal-header">
					<h5 class="modal-title">Thêm Category</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
				</div>
				<div class="modal-body">
					<div class="mb-3">
						<label for="new_categoryname" class="form-label">Category Name</label>
						<input type="text" class="form-control" id="new_categoryname" name="categoryName" required>
					</div>
					<div class="mb-3">
						<label for="new_icon" class="form-label">Icon</label>
						<input type="file" class="form-control" id="new_icon" name="icon">
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
					<button type="submit" class="btn btn-primary">Thêm</button>
				</div>
			</form>
		</div>
	</div>
</div>

<!-- ============ Modal Sửa Category ============ -->
<div class="modal" tabindex="-1" role="dialog" id="updateCategoryInfoModal">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<form id="updateCategory" method="post" onsubmit="return false;" enctype="multipart/form-data">
				<div class="modal-header">
					<h5 class="modal-title">Cập nhật Category</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
				</div>
				<div class="modal-body">
					<input type="hidden" id="categoryId_up" name="categoryId">
					<div class="mb-3">
						<label for="categoryName_up" class="form-label">Category Name</label>
						<input type="text" class="form-control" id="categoryName_up" name="categoryName" required>
					</div>
					<div class="mb-3">
						<label for="icon_up" class="form-label">Icon mới (để trống nếu không đổi)</label>
						<input type="file" class="form-control" id="icon_up" name="icon">
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
					<button type="submit" class="btn btn-primary">Cập nhật</button>
				</div>
			</form>
		</div>
	</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">
	/* ============ Load danh sách Category bằng AJAX ============ */
	function loadCategories() {
		$.getJSON(contextPath + '/api/category', function (resp) {
			var list = resp.body; // Response.body chứa List<Category>
			var tr = [];
			for (var i = 0; i < list.length; i++) {
				var iconUrl = list[i].icon ? (contextPath + '/images/' + list[i].icon) : '';
				tr.push('<tr>');
				tr.push('<td>' + list[i].categoryId + '</td>');
				tr.push('<td>' + (iconUrl ? '<img src="' + iconUrl + '" style="width:60px" class="img-fluid" alt="">' : '') + '</td>');
				tr.push('<td>' + list[i].categoryName + '</td>');
				tr.push('<td>' +
					'<a href="#" class="btn btn-sm btn-outline-warning me-1" ' +
					'onclick="showEditCategoryModal(' + list[i].categoryId + ',\'' + list[i].categoryName + '\',\'' + (list[i].icon || '') + '\')">' +
					'<i class="fas fa-edit"></i></a>' +
					'<a href="#" class="btn btn-sm btn-outline-danger" data-id="' + list[i].categoryId + '" id="btnDelete">' +
					'<i class="fas fa-trash"></i></a>' +
					'</td>');
				tr.push('</tr>');
			}
			$('#categoryTableBody').html(tr.join(''));
		});
	}
	$(document).ready(function () {
		loadCategories();
	});

	/* ============ Thêm Category ============ */
	function showCreateNewCategoryModal() {
		$('#addCategory')[0].reset();
		var modal = new bootstrap.Modal(document.getElementById('createCategoryModal'));
		modal.show();
	}
	$("form#addCategory").submit(function (e) {
		e.preventDefault();
		var formData = new FormData(this);
		$.ajax({
			url: contextPath + '/api/category/addCategory',
			type: 'POST',
			dataType: "json",
			data: formData,
			success: function (resp) {
				bootstrap.Modal.getInstance(document.getElementById('createCategoryModal')).hide();
				loadCategories();
			},
			error: function (xhr) {
				alert('Lỗi: ' + (xhr.responseJSON ? xhr.responseJSON.message : xhr.responseText));
			},
			cache: false,
			contentType: false,
			processData: false
		});
	});

	/* ============ Sửa Category ============ */
	function showEditCategoryModal(categoryId, categoryName, icon) {
		$('#categoryId_up')[0].value = categoryId;
		$('#categoryName_up')[0].value = categoryName;
		var modal = new bootstrap.Modal(document.getElementById('updateCategoryInfoModal'));
		modal.show();
	}
	$("form#updateCategory").submit(function (e) {
		e.preventDefault();
		var formData = new FormData(this);
		$.ajax({
			url: contextPath + '/api/category/updateCategory',
			type: 'PUT',
			dataType: "json",
			data: formData,
			success: function (resp) {
				bootstrap.Modal.getInstance(document.getElementById('updateCategoryInfoModal')).hide();
				loadCategories();
			},
			error: function (xhr) {
				alert('Lỗi: ' + (xhr.responseJSON ? xhr.responseJSON.message : xhr.responseText));
			},
			cache: false,
			contentType: false,
			processData: false
		});
	});

	/* ============ Xóa Category ============ */
	$(document).on('click', '#btnDelete', function () {
		var id = $(this).data('id');
		if (confirm('Bạn có chắc muốn xóa Category này?')) {
			$.ajax({
				type: "DELETE",
				url: contextPath + '/api/category/deleteCategory?categoryId=' + id,
				dataType: "json",
				success: function () {
					loadCategories();
				},
				error: function (xhr) {
					alert('Lỗi: ' + (xhr.responseJSON ? xhr.responseJSON.message : xhr.responseText));
				}
			});
		}
	});
</script>
</body>
</html>
