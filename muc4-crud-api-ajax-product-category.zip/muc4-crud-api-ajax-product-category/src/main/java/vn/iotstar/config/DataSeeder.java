package vn.iotstar.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import vn.iotstar.entity.Category;
import vn.iotstar.entity.Product;
import vn.iotstar.repository.CategoryRepository;
import vn.iotstar.repository.ProductRepository;

/** Tự sinh vài danh mục/sản phẩm mẫu khi DB rỗng, để tiện demo/chấm bài. */
@Component
public class DataSeeder implements CommandLineRunner {

	private final CategoryRepository categoryRepository;
	private final ProductRepository productRepository;

	public DataSeeder(CategoryRepository categoryRepository, ProductRepository productRepository) {
		this.categoryRepository = categoryRepository;
		this.productRepository = productRepository;
	}

	@Override
	public void run(String... args) {
		if (categoryRepository.count() > 0) {
			return;
		}

		Category c1 = new Category();
		c1.setCategoryName("Điện thoại");
		categoryRepository.save(c1);

		Category c2 = new Category();
		c2.setCategoryName("Laptop");
		categoryRepository.save(c2);

		Product p1 = new Product();
		p1.setProductName("iPhone 15");
		p1.setQuantity(10);
		p1.setUnitPrice(22000000);
		p1.setDiscount(0);
		p1.setDescription("Điện thoại iPhone 15 128GB");
		p1.setCreateDate(new java.util.Date());
		p1.setStatus((short) 1);
		p1.setCategory(c1);
		productRepository.save(p1);

		Product p2 = new Product();
		p2.setProductName("Laptop Dell XPS 13");
		p2.setQuantity(5);
		p2.setUnitPrice(35000000);
		p2.setDiscount(1000000);
		p2.setDescription("Laptop Dell XPS 13 core i7");
		p2.setCreateDate(new java.util.Date());
		p2.setStatus((short) 1);
		p2.setCategory(c2);
		productRepository.save(p2);
	}
}
