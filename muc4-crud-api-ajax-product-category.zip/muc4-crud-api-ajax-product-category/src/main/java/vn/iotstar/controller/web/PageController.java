package vn.iotstar.controller.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/** Điều hướng tới 2 trang JSP quản lý Category / Product bằng AJAX. */
@Controller
public class PageController {

	@GetMapping("/")
	public String index() {
		return "redirect:/category";
	}

	@GetMapping("/category")
	public String categoryPage() {
		return "category";
	}

	@GetMapping("/product")
	public String productPage() {
		return "product";
	}
}
