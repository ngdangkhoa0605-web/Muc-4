package vn.iotstar.controller.api;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.tags.Tag;
import vn.iotstar.entity.Category;
import vn.iotstar.entity.Product;
import vn.iotstar.model.ProductModel;
import vn.iotstar.model.Response;
import vn.iotstar.service.ICategoryService;
import vn.iotstar.service.IProductService;
import vn.iotstar.service.IStorageService;

@Tag(name = "Product API", description = "CRUD API cho bảng Product")
@RestController
@RequestMapping(path = "/api/product")
public class ProductApiController {

	@Autowired
	IProductService productService;

	@Autowired
	ICategoryService categoryService;

	@Autowired
	IStorageService storageService;

	/** Lấy tất cả sản phẩm - dùng để đổ dữ liệu vào bảng AJAX. */
	@GetMapping
	public ResponseEntity<?> getAllProduct() {
		return new ResponseEntity<Response>(new Response(true, "Thành công", productService.findAll()),
				HttpStatus.OK);
	}

	@GetMapping(path = "/{id}")
	public ResponseEntity<?> getById(@PathVariable Long id) {
		Optional<Product> product = productService.findById(id);
		if (product.isPresent()) {
			return new ResponseEntity<Response>(new Response(true, "Thành công", product.get()), HttpStatus.OK);
		}
		return new ResponseEntity<Response>(new Response(false, "Không tìm thấy", null), HttpStatus.NOT_FOUND);
	}

	/** Tìm kiếm (có phân trang) theo tên sản phẩm. */
	@GetMapping(path = "/search")
	public ResponseEntity<?> search(
			@RequestParam(required = false, defaultValue = "") String keyword,
			@RequestParam(required = false, defaultValue = "0") int page,
			@RequestParam(required = false, defaultValue = "5") int size) {
		var pageable = PageRequest.of(page, size);
		var result = productService.findByProductNameContaining(keyword, pageable);
		return new ResponseEntity<Response>(new Response(true, "Thành công", result), HttpStatus.OK);
	}

	/**
	 * Thêm sản phẩm mới. Dùng @ModelAttribute để Spring tự bind toàn bộ field
	 * form (kể cả file ảnh "imageFile") vào ProductModel, sau đó map thủ công
	 * sang Entity Product (không dùng BeanUtils.copyProperties vì 2 class có
	 * field khác kiểu dữ liệu - ví dụ categoryId (Long) ở Model >< category
	 * (Category) ở Entity).
	 */
	@PostMapping(path = "/addProduct")
	public ResponseEntity<?> addProduct(@ModelAttribute ProductModel proModel) {
		Optional<Product> optProduct = productService.findByProductName(proModel.getProductName());
		if (optProduct.isPresent()) {
			return new ResponseEntity<Response>(
					new Response(false, "Sản phẩm này đã tồn tại trong hệ thống", optProduct.get()),
					HttpStatus.BAD_REQUEST);
		}

		Product product = new Product();
		mapModelToEntity(proModel, product);

		Timestamp timestamp = new Timestamp(new Date(System.currentTimeMillis()).getTime());
		product.setCreateDate(timestamp);

		// kiểm tra tồn tại file, lưu file
		if (proModel.getImageFile() != null && !proModel.getImageFile().isEmpty()) {
			UUID uuid = UUID.randomUUID();
			String uuString = uuid.toString();
			product.setImages(storageService.getSorageFilename(proModel.getImageFile(), uuString));
			storageService.store(proModel.getImageFile(), product.getImages());
		}

		productService.save(product);
		return new ResponseEntity<Response>(new Response(true, "Thêm thành công", product), HttpStatus.OK);
	}

	@PutMapping(path = "/updateProduct")
	public ResponseEntity<?> updateProduct(@ModelAttribute ProductModel proModel) {
		if (proModel.getProductId() == null) {
			return new ResponseEntity<Response>(new Response(false, "Thiếu productId", null),
					HttpStatus.BAD_REQUEST);
		}

		Optional<Product> optProduct = productService.findById(proModel.getProductId());
		if (optProduct.isEmpty()) {
			return new ResponseEntity<Response>(new Response(false, "Không tìm thấy Product", null),
					HttpStatus.BAD_REQUEST);
		}

		Product product = optProduct.get();
		mapModelToEntity(proModel, product);

		// kiểm tra tồn tại file, lưu file mới (nếu có)
		if (proModel.getImageFile() != null && !proModel.getImageFile().isEmpty()) {
			UUID uuid = UUID.randomUUID();
			String uuString = uuid.toString();
			product.setImages(storageService.getSorageFilename(proModel.getImageFile(), uuString));
			storageService.store(proModel.getImageFile(), product.getImages());
		}

		productService.save(product);
		return new ResponseEntity<Response>(new Response(true, "Cập nhật thành công", product), HttpStatus.OK);
	}

	@DeleteMapping(path = "/deleteProduct")
	public ResponseEntity<?> deleteProduct(@Validated @RequestParam("productId") Long productId) {
		Optional<Product> optProduct = productService.findById(productId);
		if (optProduct.isEmpty()) {
			return new ResponseEntity<Response>(new Response(false, "Không tìm thấy Product", null),
					HttpStatus.BAD_REQUEST);
		}
		productService.delete(optProduct.get());
		return new ResponseEntity<Response>(new Response(true, "Xóa thành công", optProduct.get()), HttpStatus.OK);
	}

	private void mapModelToEntity(ProductModel proModel, Product product) {
		product.setProductName(proModel.getProductName());
		product.setQuantity(proModel.getQuantity());
		product.setUnitPrice(proModel.getUnitPrice());
		product.setDiscount(proModel.getDiscount());
		product.setDescription(proModel.getDescription());
		product.setStatus(proModel.getStatus());

		if (proModel.getCategoryId() != null) {
			Category category = categoryService.findById(proModel.getCategoryId())
					.orElseThrow(() -> new IllegalArgumentException(
							"Không tìm thấy Category id = " + proModel.getCategoryId()));
			product.setCategory(category);
		}
	}
}
