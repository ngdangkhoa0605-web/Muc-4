package vn.iotstar.controller.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import vn.iotstar.service.IStorageService;

/**
 * Phục vụ ảnh (icon Category / images Product) đã upload lưu trong thư mục
 * storage.location (cấu hình tại application.properties).
 * URL: /images/{filename}
 */
@RestController
public class ImageController {

	@Autowired
	private IStorageService storageService;

	@GetMapping("/images/{filename:.+}")
	public ResponseEntity<Resource> serveFile(@PathVariable String filename) {
		Resource file = storageService.loadAsResource(filename);
		return ResponseEntity.ok().body(file);
	}
}
