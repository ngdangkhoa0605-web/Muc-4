package vn.iotstar.controller.api;

import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.v3.oas.annotations.tags.Tag;
import vn.iotstar.entity.Category;
import vn.iotstar.model.Response;
import vn.iotstar.service.ICategoryService;
import vn.iotstar.service.IStorageService;

@Tag(name = "Category API", description = "CRUD API cho bảng Category")
@RestController
@RequestMapping(path = "/api/category")
public class CategoryAPIController {

	@Autowired
	private ICategoryService categoryService;

	@Autowired
	IStorageService storageService;

	/** Lấy tất cả danh mục - dùng để đổ dữ liệu vào bảng AJAX. */
	@GetMapping
	public ResponseEntity<?> getAllCategory() {
		return new ResponseEntity<Response>(new Response(true, "Thành công", categoryService.findAll()),
				HttpStatus.OK);
	}

	/** Lấy 1 danh mục theo id (REST chuẩn, bổ sung thêm cho tiện gọi từ JS). */
	@GetMapping(path = "/{id}")
	public ResponseEntity<?> getById(@PathVariable Long id) {
		Optional<Category> category = categoryService.findById(id);
		if (category.isPresent()) {
			return new ResponseEntity<Response>(new Response(true, "Thành công", category.get()), HttpStatus.OK);
		}
		return new ResponseEntity<Response>(new Response(false, "Không tìm thấy", null), HttpStatus.NOT_FOUND);
	}

	/** Lấy 1 danh mục theo id (giữ đúng endpoint theo tài liệu hướng dẫn gốc). */
	@PostMapping(path = "/getCategory")
	public ResponseEntity<?> getCategory(@Validated @RequestParam("id") Long id) {
		Optional<Category> category = categoryService.findById(id);
		if (category.isPresent()) {
			return new ResponseEntity<Response>(new Response(true, "Thành công", category.get()), HttpStatus.OK);
		} else {
			return new ResponseEntity<Response>(new Response(false, "Thất bại", null), HttpStatus.NOT_FOUND);
		}
	}

	/** Tìm kiếm (có phân trang) theo tên danh mục. */
	@GetMapping(path = "/search")
	public ResponseEntity<?> search(
			@RequestParam(required = false, defaultValue = "") String keyword,
			@RequestParam(required = false, defaultValue = "0") int page,
			@RequestParam(required = false, defaultValue = "5") int size) {
		var pageable = org.springframework.data.domain.PageRequest.of(page, size);
		var result = categoryService.findByCategoryNameContaining(keyword, pageable);
		return new ResponseEntity<Response>(new Response(true, "Thành công", result), HttpStatus.OK);
	}

	@PostMapping(path = "/addCategory")
	public ResponseEntity<?> addCategory(
			@Validated @RequestParam("categoryName") String categoryName,
			@RequestParam(value = "icon", required = false) MultipartFile icon) {

		Optional<Category> optCategory = categoryService.findByCategoryName(categoryName);
		if (optCategory.isPresent()) {
			return new ResponseEntity<Response>(
					new Response(false, "Category đã tồn tại trong hệ thống", optCategory.get()),
					HttpStatus.BAD_REQUEST);
		} else {
			Category category = new Category();
			// kiểm tra tồn tại file, lưu file
			if (icon != null && !icon.isEmpty()) {
				UUID uuid = UUID.randomUUID();
				String uuString = uuid.toString();
				// lưu file vào trường icon
				category.setIcon(storageService.getSorageFilename(icon, uuString));
				storageService.store(icon, category.getIcon());
			}
			category.setCategoryName(categoryName);
			categoryService.save(category);
			return new ResponseEntity<Response>(new Response(true, "Thêm thành công", category), HttpStatus.OK);
		}
	}

	@PutMapping(path = "/updateCategory")
	public ResponseEntity<?> updateCategory(
			@Validated @RequestParam("categoryId") Long categoryId,
			@Validated @RequestParam("categoryName") String categoryName,
			@RequestParam(value = "icon", required = false) MultipartFile icon) {

		Optional<Category> optCategory = categoryService.findById(categoryId);
		if (optCategory.isEmpty()) {
			return new ResponseEntity<Response>(new Response(false, "Không tìm thấy Category", null),
					HttpStatus.BAD_REQUEST);
		}

		// kiểm tra tồn tại file, lưu file
		if (icon != null && !icon.isEmpty()) {
			UUID uuid = UUID.randomUUID();
			String uuString = uuid.toString();
			optCategory.get().setIcon(storageService.getSorageFilename(icon, uuString));
			storageService.store(icon, optCategory.get().getIcon());
		}

		optCategory.get().setCategoryName(categoryName);
		categoryService.save(optCategory.get());
		return new ResponseEntity<Response>(new Response(true, "Cập nhật thành công", optCategory.get()),
				HttpStatus.OK);
	}

	@DeleteMapping(path = "/deleteCategory")
	public ResponseEntity<?> deleteCategory(@Validated @RequestParam("categoryId") Long categoryId) {
		Optional<Category> optCategory = categoryService.findById(categoryId);
		if (optCategory.isEmpty()) {
			return new ResponseEntity<Response>(new Response(false, "Không tìm thấy Category", null),
					HttpStatus.BAD_REQUEST);
		}
		categoryService.delete(optCategory.get());
		return new ResponseEntity<Response>(new Response(true, "Xóa thành công", optCategory.get()), HttpStatus.OK);
	}
}
