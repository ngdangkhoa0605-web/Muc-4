package vn.iotstar.model;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO nhận dữ liệu từ form (multipart) khi thêm/sửa Product, tách biệt với
 * Entity vì Entity dùng để lưu DB còn Model dùng để nhận input có kèm file.
 */
@Data
@NoArgsConstructor
public class ProductModel {
	private Long productId;
	private String productName;
	private int quantity;
	private double unitPrice;
	private double discount;
	private String description;
	private Long categoryId;
	private short status;
	private MultipartFile imageFile;
}
