package vn.iotstar;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/** Cho phép đóng gói WAR để deploy Tomcat ngoài (cần cho JSP hoạt động ổn định). */
public class ServletInitializer extends SpringBootServletInitializer {
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(Muc4Application.class);
	}
}
