# Mục 4: CRUD API (REST) + AJAX cho Product và Category

Bài tập theo hướng dẫn:
- `HƯỚNG DẪN CRUD API CATEGORY TRÊN SPRING BOOT 3.pdf`
- `HƯỚNG DẪN AJAX VỚI RESTFUL API TRONG SPRING BOOT.pdf` (bao gồm cả phần
  "Bài tập thêm: Xây dựng chức năng CRUD bảng Products bằng Ajax")

**Yêu cầu**: Viết API và render lên AJAX cho chức năng CRUD trên bảng
`Product` và bảng `Category`.

## 1. Công nghệ

- Spring Boot 3.1.5, Spring Data JPA, MySQL
- JSP (view) + jQuery AJAX (gọi REST API, không load lại trang)
- Swagger 3 (springdoc-openapi) - xem tại `/swagger-ui.html`
- Upload ảnh lưu ổ đĩa local (`IStorageService`)

## 2. Package `vn.iotstar` (bám theo đúng cấu trúc tài liệu hướng dẫn)

```
entity/            Category, Product
repository/          CategoryRepository, ProductRepository
model/                Response (bọc kết quả API), ProductModel (DTO nhận form)
exception/             StorageException, StorageFileNotFoundException
config/                 StorageProperties, WebMvcConfig (JSP ViewResolver), DataSeeder
service/                 ICategoryService/CategoryServiceImpl
                        IProductService/ProductServiceImpl
                        IStorageService/FileSystemStorageServiceImpl (upload ảnh)
controller/api/          CategoryAPIController (/api/category)
                        ProductApiController (/api/product)
controller/web/          PageController (route JSP), ImageController (phục vụ ảnh)
webapp/WEB-INF/views/     category.jsp, product.jsp (CRUD bằng AJAX)
```

## 3. Hai điểm đã CHỈNH SỬA so với tài liệu gốc (quan trọng, cần biết để bảo vệ bài)

### a) Bỏ `springfox-swagger-ui` (chỉ dùng `springdoc-openapi`)
Tài liệu "CẤU HÌNH SWAGGER2 VÀ SWAGGER 3" ghi thêm cả
`io.springfox:springfox-swagger-ui:3.0.0` lẫn `springdoc-openapi`. Tuy
nhiên **springfox-swagger-ui 3.0.0 được build cho namespace
`javax.servlet.*`** (thời Spring Boot 2), còn Spring Boot 3 dùng
**`jakarta.servlet.*`** - nếu thêm springfox vào sẽ gây xung đột
classpath và có thể khiến ứng dụng không khởi động được. Chỉ cần
`springdoc-openapi-starter-webmvc-ui` là đã đủ Swagger UI đầy đủ cho
Spring Boot 3 (đúng như ảnh chụp màn hình trong tài liệu cũng cho thấy
URL `swagger-ui/index.html` - đây chính là URL của springdoc, không phải
springfox).

### b) Sửa lỗi binding dữ liệu trong `addProduct`
Đoạn code mẫu trong tài liệu viết:
```java
ProductModel proModel = new ProductModel();
BeanUtils.copyProperties(proModel, product); // proModel đang RỖNG!
```
`proModel` ở đây là object rỗng vừa khởi tạo (`new ProductModel()`), chưa
được gán bất kỳ giá trị nào từ request, nên `BeanUtils.copyProperties` sẽ
copy toàn bộ giá trị **null/mặc định** sang `product` - dữ liệu form gửi
lên sẽ bị mất hoàn toàn. Bài làm này đã sửa bằng cách dùng
`@ModelAttribute ProductModel proModel` để Spring tự động bind toàn bộ
field (kể cả file ảnh) từ multipart form vào `proModel`, sau đó map thủ
công từng field sang `Product` (không dùng `BeanUtils.copyProperties` vì
2 lớp có field khác kiểu: `categoryId` (Long) ở Model >< `category`
(Category) ở Entity).

## 4. Cài đặt & chạy

### a) Tạo Database
Không cần tạo tay - `application.properties` đã có
`createDatabaseIfNotExist=true`, Hibernate (`ddl-auto=update`) sẽ tự tạo
bảng `Categories`, `Products`.

### b) Cấu hình
Sửa `src/main/resources/application.properties`:
```properties
spring.datasource.username=root
spring.datasource.password=your_mysql_password
storage.location=upload-dir   # đổi thành đường dẫn tuyệt đối nếu cần, vd D:/upload-muc4
```

### c) Chạy
```bash
mvn clean spring-boot:run
```
Truy cập:
- Trang quản lý Category (AJAX): `http://localhost:8080/category`
- Trang quản lý Product (AJAX): `http://localhost:8080/product`
- Swagger UI: `http://localhost:8080/swagger-ui.html`

`DataSeeder` tự tạo sẵn 2 danh mục + 2 sản phẩm mẫu khi chạy lần đầu (DB
rỗng) để tiện demo ngay.

## 5. Danh sách API

| Chức năng | Method | URL |
|---|---|---|
| Danh sách Category | GET | `/api/category` |
| Chi tiết Category theo id | GET | `/api/category/{id}` |
| Chi tiết Category theo id (theo đúng tài liệu gốc) | POST | `/api/category/getCategory?id=` |
| Tìm kiếm + phân trang Category | GET | `/api/category/search?keyword=&page=0&size=5` |
| Thêm Category | POST (multipart) | `/api/category/addCategory` (categoryName, icon) |
| Sửa Category | PUT (multipart) | `/api/category/updateCategory` (categoryId, categoryName, icon) |
| Xóa Category | DELETE | `/api/category/deleteCategory?categoryId=` |
| Danh sách Product | GET | `/api/product` |
| Chi tiết Product theo id | GET | `/api/product/{id}` |
| Tìm kiếm + phân trang Product | GET | `/api/product/search?keyword=&page=0&size=5` |
| Thêm Product | POST (multipart) | `/api/product/addProduct` (productName, categoryId, quantity, unitPrice, discount, description, status, imageFile) |
| Sửa Product | PUT (multipart) | `/api/product/updateProduct` (thêm productId) |
| Xóa Product | DELETE | `/api/product/deleteProduct?productId=` |
| Xem ảnh đã upload | GET | `/images/{filename}` |

## 6. Đưa code lên GitHub (để nộp link vào utexlms trước 17g30 hôm nay)

```bash
cd muc4-crud-api-ajax-product-category
git init
git add .
git commit -m "Muc 4: CRUD API + AJAX cho Product va Category"
git branch -M main
git remote add origin <URL_REPO_GITHUB_BAN_VUA_TAO>
git push -u origin main
```
(Tạo repo mới trên github.com trước, ví dụ đặt tên
`muc4-crud-api-ajax-product-category`, để **Public** hoặc **Private** đều
được tùy yêu cầu môn học, sau đó copy URL vào lệnh `git remote add`
ở trên.)
